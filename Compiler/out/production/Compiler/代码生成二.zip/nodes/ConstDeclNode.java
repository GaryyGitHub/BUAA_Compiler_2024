package nodes;

import frontend.Token;
import utils.IOUtils;

import java.util.List;

/**
 * @author Gary
 * @Description: 常量声明
 * @date 2024/10/13 10:44
 * ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'
 */
public class ConstDeclNode {
    private Token constToken;
    private BTypeNode bTypeNode;
    private List<ConstDefNode> constDefNodes;
    private List<Token> commaTokens; // 用来存逗号
    private Token semicnToken;

    public BTypeNode getBTypeNode() {
        return bTypeNode;
    }

    public List<ConstDefNode> getConstDefNodes() {
        return constDefNodes;
    }

    public ConstDeclNode(Token constToken, BTypeNode bTypeNode, List<ConstDefNode> constDefNodes, List<Token> commaTokens, Token semicnToken) {
        this.constToken = constToken;
        this.bTypeNode = bTypeNode;
        this.constDefNodes = constDefNodes;
        this.commaTokens = commaTokens;
        this.semicnToken = semicnToken;
    }

    public void print() {
        IOUtils.write(constToken.toString());
        bTypeNode.print();
        constDefNodes.get(0).print();
        for (int i = 1; i < constDefNodes.size(); i++) {
            IOUtils.write(commaTokens.get(i - 1).toString());
            constDefNodes.get(i).print();
        }
        IOUtils.write(semicnToken.toString());
        IOUtils.write("<ConstDecl>\n");
    }

    // ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'
    public void buildIr() {
        for (ConstDefNode constDefNode : constDefNodes) {
            // 注意此处调用buildIr要传参bTypeNode，用来判断是int还是char
            constDefNode.buildIr(bTypeNode);
        }
    }
}

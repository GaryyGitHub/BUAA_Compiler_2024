package nodes;

import frontend.Token;
import utils.IOUtils;

import java.util.List;

/**
 * @author Gary
 * @Description: 变量声明
 * @date 2024/10/13 10:47
 * VarDecl -> BType VarDef { ',' VarDef } ';'
 */
public class VarDeclNode {
    private BTypeNode bTypeNode;
    private List<VarDefNode> varDefNodes;
    private List<Token> commas;
    private Token semicolon;

    public BTypeNode getBTypeNode() {
        return bTypeNode;
    }

    public List<VarDefNode> getVarDefNodes() {
        return varDefNodes;
    }

    public VarDeclNode(BTypeNode bTypeNode, List<VarDefNode> varDefNodes, List<Token> commas, Token semicolon) {
        this.bTypeNode = bTypeNode;
        this.varDefNodes = varDefNodes;
        this.commas = commas;
        this.semicolon = semicolon;
    }

    public void print() {
        bTypeNode.print();
        varDefNodes.get(0).print();
        for (int i = 1; i < varDefNodes.size(); i++) {
            IOUtils.write(commas.get(i-1).toString());
            varDefNodes.get(i).print();
        }
        IOUtils.write(semicolon.toString());
        IOUtils.write("<VarDecl>\n");
    }

    public void buildIr() {
        for (VarDefNode varDefNode : varDefNodes) {
            varDefNode.buildIr(bTypeNode);
        }
    }
}

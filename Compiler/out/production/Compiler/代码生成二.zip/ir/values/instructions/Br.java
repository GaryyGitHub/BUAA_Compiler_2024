package ir.values.instructions;

import ir.types.VoidType;
import ir.values.BasicBlock;
import ir.values.Value;
import utils.IrUtils;

/**
 * @author Gary
 * @Description: 跳转指令
 * 有条件跳转：br i1 <cond>, label <iftrue>, label <iffalse>
 * 无条件跳转：br label <dest>
 * @date 2024/11/20 1:13
 */
public class Br extends Instruction{
    // 标志是否为有条件跳转
    private boolean isConditional = false;

    /**
     * 无条件跳转指令
     * @param parent 一定是基本块
     * @param target 跳转到的目标基本块
     */
    public Br(BasicBlock parent, BasicBlock target) {
        super("", new VoidType(), parent, target);
        isConditional = false;
    }

    /**
     * 有条件跳转指令
     * @param cond          跳转条件
     * @param trueBranch    条件为真，跳转到的目标基本块
     * @param falseBranch   条件为假，跳转到的目标基本块
     */
    public Br(BasicBlock parent, Value cond, BasicBlock trueBranch, BasicBlock falseBranch) {
        // cond, trueBranch, falseBranch都是operands
        super("", new VoidType(), parent, cond, trueBranch, falseBranch);
        isConditional = true;
    }

    public String toString() {
        if (isConditional) {
            // 有条件跳转
            return "br " +
                    IrUtils.typeAndNameStr(getOperands().get(0)) + ", " +
                    IrUtils.typeAndNameStr(getOperands().get(1)) + ", " +
                    IrUtils.typeAndNameStr(getOperands().get(2));
        } else {
            // 无条件跳转
            return "br " + IrUtils.typeAndNameStr(getOperands().get(0));
        }
    }
}

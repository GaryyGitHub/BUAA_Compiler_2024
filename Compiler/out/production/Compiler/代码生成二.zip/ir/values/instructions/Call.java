package ir.values.instructions;

import ir.types.VoidType;
import ir.values.BasicBlock;
import ir.values.Function;
import ir.values.Value;
import utils.IrUtils;

import java.util.ArrayList;

/**
 * @author Gary
 * @Description: 函数调用指令
 * <result> = call [ret attrs] <ty> <name>(<...args>)
 * @date 2024/11/20 13:30
 */
public class Call extends Instruction {
    private Function function;  // 函数对象

    /**
     * call指令构造函数，ValueType一定是函数返回值的ValueType
     * @param parent    所属基本块
     * @param function  operands[0] 函数对象
     * @param rArgs     operands[1,2,...] 实参列表
     */
    public Call(String name, BasicBlock parent, Function function, ArrayList<Value> rArgs) {
        super(name, function.getReturnType(), parent, new ArrayList<Value>() {{
            add(function);
            addAll(rArgs);
        }}.toArray(new Value[0]));  // 这个new Value[0]是为了告知toArray方法，该数组是Value类型的
        this.function = function;
    }

    // 有两种形式：
    // 1. 有返回值：%3 = call i32 @bar(i32 %1, i32 %2)
    // 2. 无返回值：call void @foo(i32 %1)
    public String toString() {
        // ops是指令的操作数列表
        ArrayList<Value> ops = new ArrayList<>(getOperands());
        // 指令的第一个参数为函数对象，把它取出来
        Function func = (Function) ops.get(0);
        StringBuilder sb = new StringBuilder();
        // 若是有返回值：还需要在前面加上形如 "%3 = " 的语句
        if (!(function.getReturnType() instanceof VoidType)) {
            sb.append(getName()).append(" = ");
        }
        // 接下来是1和2共同的 "call i32 @bar"
        sb.append("call ").append(func.getReturnType()).append(" ").append(func.getName()).append("(");
        // 有参数的函数，需要把参数列表也打印出来: "(i32 %1, i32 %2)"
        if (ops.size() >= 1) {
            ops.remove(0);  // 移除函数对象
            IrUtils.appendSBParamList(sb, ops);
        }
        sb.append(")");
        return sb.toString();
    }

}

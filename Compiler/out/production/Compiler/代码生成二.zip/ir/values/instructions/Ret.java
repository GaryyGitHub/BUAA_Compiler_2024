package ir.values.instructions;

import ir.types.VoidType;
import ir.values.BasicBlock;
import ir.values.Value;
import utils.IrUtils;

/**
 * @author Gary
 * @Description: ret 指令
 * 1. ret <type> <value>
 * 2. ret void
 * @date 2024/11/19 22:28
 */
public class Ret extends Instruction {
    // 无返回值：ret void
    public Ret(BasicBlock parent) {
        super("", new VoidType(), parent);
    }

    // 有返回值：ret <type> <value>
    public Ret(BasicBlock parent, Value retVal) {
        super("", retVal.getType(), parent, retVal);
    }

    // ret i32 %24
    // ret void
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ret ");  // "ret "
        if (getType() instanceof VoidType) {
            sb.append("void");   // "void"
        } else {
            // "i32 %24"
            sb.append(IrUtils.typeAndNameStr(getOperands().get(0)));
        }
        return sb.toString();
    }
}

package ir.values.instructions;

import ir.types.PointerType;
import ir.types.ValueType;
import ir.values.BasicBlock;
import ir.values.constants.ConstArray;

/**
 * @author Gary
 * @Description: 内存申请指令，对应的Value应为指针类型
 * <result> = alloca <type>
 * @date 2024/11/18 17:27
 */
public class Alloca extends Instruction {
    // ============ 成员变量 ============
    private ConstArray initArray = null;    // 用于处理常量数组
    private ValueType allocatedType = null; // 要分配的类型

    public ConstArray getInitArray() {
        return initArray;
    }

    // ============ 构造函数 ============
    /**
     * 专门用来处理 没有操作数的指令
     * @param name          指令Value的名称
     * @param pointingType  要指向的类型
     * @param parent        所在基本块(一定是BasicBlock)
     */
    public Alloca(String name, ValueType pointingType, BasicBlock parent) {
        super(name, new PointerType(pointingType), parent);
        allocatedType = pointingType;
    }

    /**
     * 专门用来处理带有初值的数组常量
     * @param name          指令Value的名称
     * @param pointingType  要指向的类型
     * @param parent        所在基本块(一定是BasicBlock)
     * @param initArray     常量初值
     */
    public Alloca (String name, ValueType pointingType, BasicBlock parent, ConstArray initArray) {
        super(name, new PointerType(pointingType), parent);
        this.initArray = initArray;
        this.allocatedType = pointingType;
    }

    public String toString() {
        return getName() + " = alloca " + allocatedType;
    }
}

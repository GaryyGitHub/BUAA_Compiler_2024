package ir.values.instructions;

import ir.types.IntType;
import ir.values.BasicBlock;
import ir.values.Value;
import utils.IrUtils;

/**
 * @author Gary
 * @Description: 整数截断，将i32截断为i8
 * <result> = trunc <ty> <value> to <ty2>
 * @date 2024/11/22 11:02
 */
public class Trunc extends Instruction {
    public Trunc(String name, BasicBlock parent, Value value) {
        super(name, new IntType(8), parent, value);
    }

    // %1 = trunc i32 %2 to i8
    public String toString() {
        // "%1 = trunc "
        return getName() + " = trunc " +
                // "i32 %2"
                IrUtils.typeAndNameStr(getOperands().get(0)) +
                // " to i8"
                " to i8";
    }
}

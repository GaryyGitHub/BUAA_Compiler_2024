package ir.values.instructions;

import ir.values.BasicBlock;
import ir.values.Value;

/**
 * @author Gary
 * @Description: 乘法指令
 * <result> = mul <ty> <op1>, <op2>
 * @date 2024/11/21 16:39
 */
public class Mul extends MathInstruction {
    public Mul(String name, BasicBlock parent, Value op1, Value op2) {
        super(name, parent, op1, op2);
    }

    public String toString() {
        return toMathInstructionString("mul");
    }
}

package ir.values.instructions;

import ir.types.IntType;
import ir.values.BasicBlock;
import ir.values.Value;
import utils.IrUtils;

/**
 * @author Gary
 * @Description:
 * <result> = icmp <cond> <ty> <op1>, <op2>
 * @date 2024/11/20 20:13
 */
public class Icmp extends Instruction {
    private CondType condType;

    public Icmp(String name, BasicBlock parent, CondType condType, Value op1, Value op2) {
        super(name, new IntType(1), parent, op1, op2);
        this.condType = condType;
    }

    // 枚举一下可能的比较条件类型
    public enum CondType {
        EQL("eq"),  // ==
        NEQ("ne"),  // !=
        LEQ("sle"), // <=
        LSS("slt"), // <
        GEQ("sge"), // >=
        GRE("sgt"); // >
        private String irString;
        CondType(String irString) {
            this.irString = irString;
        }
        public String toString() {
            return this.irString;
        }
    }

    // 形如：%5 = icmp ne i32 0, %4
    public String toString() {
        return getName() + " = icmp " +         // "%5 = icmp"
                condType + " " +                // "ne "
                IrUtils.typeAndNameStr(getOperands().get(0)) + ", " +  // "i32 0, "
                getOperands().get(1).getName(); // "%4"
    }
}

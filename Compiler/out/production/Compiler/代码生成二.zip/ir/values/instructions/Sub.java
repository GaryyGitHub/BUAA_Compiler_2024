package ir.values.instructions;

import ir.values.BasicBlock;
import ir.values.Value;

/**
 * @author Gary
 * @Description: 减法指令，也用在一元表达式中负号的处理
 * <result> = sub <ty> <op1>, <op2>
 * @date 2024/11/20 19:53
 */
public class Sub extends MathInstruction {
    public Sub(String name, BasicBlock parent, Value op1, Value op2) {
        super(name, parent, op1, op2);
    }

    public String toString() {
        return toMathInstructionString("sub");
    }
}

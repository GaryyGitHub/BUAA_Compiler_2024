package ir.values;

import ir.types.ValueType;

import java.util.ArrayList;

/**
 * @author Gary
 * @Description: 基本的Value类，是所有东西的父类。一切皆value
 * @date 2024/11/17 16:08
 */
public class Value {
    // ============== 基本属性 ==============
    private int id;         // 唯一标识符
    private String name;    // 虚拟寄存器名称
    private ValueType type; // 类型
    private Value parent;   // 包含当前value的父value，如Instruction在BasicBlock中
    private boolean isArg = false;  // 是否是函数参数，默认不是
    private int argId = 0;     // 第几个参数，从0开始
    private ArrayList<User> users = new ArrayList<>();  // 使用当前value的User列表

    private static int idCnt = 0;   // 用于生成唯一标识符
    // 唯一标识符按顺序增加
    private static int applyNewId() {
        return idCnt++;
    }

    // ============== getter/setter ==============
    public ValueType getType() {
        return type;
    }

    public Value getParent() {
        return parent;
    }

    public String getName() {
        return name;
    }

    // ============== 构造函数 ==============
    // 默认构造函数
    public Value(String name, ValueType type, Value parent) {
        this.id = applyNewId();
        this.name = name;
        this.type = type;
        this.parent = parent;
    }

    // 下面这个专门在Function.addArgsByValueType中使用，区别在于多设置isArg和argId
    public Value(String name, ValueType type, Value parent, int argId) {
        this.id = applyNewId();
        this.name = name;
        this.type = type;
        this.parent = parent;
        this.isArg = true;
        this.argId = argId;
    }

    // ============== 相关方法 ==============
    // 向users表中添加user
    public void addUser(User user) {
        this.users.add(user);
    }

    public String toString() {
        return type + " " + name;
    }
}

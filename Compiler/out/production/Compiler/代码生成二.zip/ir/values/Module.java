package ir.values;

import ir.types.VoidType;

import java.util.ArrayList;

/**
 * @author Gary
 * @Description:
 * @date 2024/11/17 19:33
 */
public class Module extends Value {
    // 单例模式
    private static final Module module = new Module();
    public static Module getInstance() {
        return module;
    }
    private Module() {
        super("Module", new VoidType(), null);
    }
    // =========== 变量定义 ===========
    // 全部函数表
    public ArrayList<Function> functions = new ArrayList<>();
    // 全部全局变量表
    public ArrayList<GlobalVariable> globalVariables = new ArrayList<>();

    // =========== 常用方法 ===========
    // 向全部函数表添加函数
    public static void addFunction(Function function) {
        module.functions.add(function);
    }

    public static void addGlobalVariable (GlobalVariable globalVariable) {
        module.globalVariables.add(globalVariable);
    }

    // 生成中间代码的字符串
    public String toString() {
        StringBuilder sb = new StringBuilder();
        // 防止没有全局变量的时候还多输出一个换行符
        if (!globalVariables.isEmpty()) {
            for (GlobalVariable globalVariable : globalVariables) {
                sb.append(globalVariable);
            }
            sb.append("\n");
        }
        if (!functions.isEmpty()) {
            for (Function function : functions) {
                sb.append(function);
            }
        }
        return sb.toString();
    }
}

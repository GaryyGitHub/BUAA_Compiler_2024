package ir.values;

import ir.types.PointerType;
import ir.values.constants.Constant;

import java.util.ArrayList;

/**
 * @author Gary
 * @Description: 全局变量
 * @date 2024/11/17 21:03
 */
public class GlobalVariable extends User {
    private boolean isConst;
    private Constant initValue = null;

    public Constant getInitValue() {
        return initValue;
    }

    /**
     * 对于 常量（const）声明，一定要初始化
     * 全局变量本身以指针形式存在
     * 全局变量在输出为LLVM时，以@开头
     */
    public GlobalVariable(String name, boolean isConst, Constant initValue) {
        super("@" + name, // 输出的名字形如 @name
                new PointerType(initValue.getType()),   // 全局变量本身以指针形式存在
                Module.getInstance(), // 当前value的父value就是Module根节点
                new ArrayList<>(){{ add(initValue); }});
        this.isConst = isConst;
        this.initValue = initValue;
    }

    // @a = dso_local global [3 x i32] [i32 1, i32 2, i32 3]
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getName()).append(" = dso_local ");
        // 常量或变量
        if (isConst) {
            sb.append("constant ");
        } else {
            sb.append("global ");
        }
        // getOperands().get(0)就是初始化的值
        sb.append(getOperands().get(0).getType());
        // "[i32 1, i32 2, i32 3]"
        sb.append(" ").append(getOperands().get(0)).append("\n");
        return sb.toString();
    }
}

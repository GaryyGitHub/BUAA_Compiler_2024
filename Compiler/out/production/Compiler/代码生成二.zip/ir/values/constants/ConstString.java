package ir.values.constants;

import ir.types.ArrayType;
import ir.types.IntType;
import utils.IrUtils;

/**
 * @author Gary
 * @Description: 字符串常量
 * @date 2024/11/18 11:38
 */
public class ConstString extends Constant {
    private String content;
    public ConstString(String content) {
        // 长度要算上结尾的\00!!
        super(new ArrayType(new IntType(8), IrUtils.getFormatStrLen(content) + 1));
        this.content = content;
    }

    // 形如：c"hello\0a\00"
    public String toString() {
        return " c\"" + content + "\\00\"";
    }
}

package error;

/**
 * @author Gary
 * @Description: 错误类型枚举
 * @date 2024/9/24 18:16
 */
public enum ErrorType {
    a,b,c,d,e,f,g,h,i,j,k,l,m
}
